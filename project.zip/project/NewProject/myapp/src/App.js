import './App.css';
import Home from './Components/Home';
import Skills from './Components/Skills'
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/skills" element={<Skills/>} />
    </Routes>
    </BrowserRouter>
  );
}

export default App;
