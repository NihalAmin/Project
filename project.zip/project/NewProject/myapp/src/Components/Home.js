import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'
import UseEffect from './UseEffect'
import Skills from './Skills'

function Home() {
  return (
    <div>
    <Navbar />
    {/* <UseEffect /> */}
    <h2>It all started with a random letter. Several of those were joined forces to create a random word. The words decided to get together and form a random sentence. They decided not to stop there and it wasn't long before a random paragraph had been cobbled together. The question was whether or not they could continue the momentum long enough to create a random short story.</h2>
    <Footer />
    </div>
  )
}

export default Home