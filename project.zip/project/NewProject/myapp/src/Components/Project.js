import React, { Component } from 'react'

export default class ChangeTextCaseWithTheme extends Component {
    constructor(){
        super()
        this.state ={
            text:'',
            theme:'light' //default theme
        };
        
        this.handleChange =this.handleChange.bind(this);
        this.ChangeTextToLowerCase =this.ChangeTextToLowerCase.bind(this);
        this.ChangeTextToUpperCase =this.ChangeTextToUpperCase.bind(this);
        this.toggleTheme =this.toggleTheme.bind(this);
        handleChange(event){
            this.setState({text:event.target.value});
        }
        this.ChangeTextToLowerCase(){
            this.setState({text:this.state.text.toLowerCase()});
        }
        this.ChangeTextToUpperCase(){
            this.setState({text:this.state.text.toUpperCase()});
        }
    }
  render() {
    return (
      <div>ChangeTextCaseWithTheme</div>
    )
  }
}
