import React from 'react'
import './Skills.css'

function Skills() {
  return (
    <div><b>Skills</b><br/>
    
        <li>HTML</li>
        <li>CSS</li>
        <li>Bootstrap</li>
        <li>JavaScript</li>
        <li>NodeJS</li>
        <li>Express.js</li>
        <li>React.js</li>
        <li>PostgreSQL</li>
    
    </div>
  )
}

export default Skills