import React from 'react'

function Greeting(props) {
  return (
    <div><h1>Good morning {props.name} </h1></div>
  )
}

export default Greeting