import React from 'react'


function Functional() {
  return (
    <div>
       ClassComponent 
    </div>
  )
}

export default Functional