import React from 'react'

function Information(props) {
  return (
    <div>
        <h1>{props.name}</h1>
        <h1>{props.age}</h1>
        <h1>{props.department}</h1>
        <h1>{props.course}</h1>
        
        </div>
  )
}

export default Information