import React, { Component } from 'react'

export default class Count extends Component {
    constructor()
    {
        super()
        this.state={
            count1:0,
            count2:0,
            count3:1,
            count4:1,
        }

    }

    incrementCount =() =>{
        this.setState({count1:this.state.count1 + 1})
    }
    decrenentCount =() =>{
        this.setState({count2:this.state.count2 - 1})
    }
    MultiCount =() =>{
        this.setState({count3:this.state.count3 * 2})
    }
    divCount =() =>{
        this.setState({count4:this.state.count4 / 2})
    }
  render() {
    return (
      <div>
        <button type="button" class="btn btn-success" onClick={this.incrementCount}>increment Count</button>
        <h2>Count: {this.state.count1}</h2>
        <button type="button" class="btn btn-danger" onClick={this.decrenentCount}>decrement Count</button>
        <h2>Count: {this.state.count2}</h2>
        <button type="button" class="btn btn-primary" onClick={this.MultiCount}>multi Count</button>
        <h2>Count: {this.state.count3}</h2>
        <button type="button" class="btn btn-warning" onClick={this.divCount}>div Count</button>
        <h2>Count: {this.state.count4}</h2>
        
      </div>
    )
  }
}
