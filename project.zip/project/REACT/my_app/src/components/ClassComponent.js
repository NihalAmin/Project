import React, { Component } from 'react'

export default class ClassComponent extends Component {

    constructor(){
        super()
        this.msg ="message Components"
    }
  render() {
    return (
      <div>
        <h1>{this.msg}</h1>
      </div>
    )
  }
}
